from flask import Flask, render_template, request
import sqlite3

app = Flask(__name__)

conn = sqlite3.connect('buspass.db')
conn.execute('''
CREATE TABLE IF NOT EXISTS passes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    destination TEXT,
    ticket_type TEXT,
    amount TEXT
)
''')
conn.close()

@app.route('/', methods=['GET', 'POST'])
def home():
    details = None

    if request.method == 'POST':
        name = request.form['name']
        destination = request.form['destination']
        ticket_type = request.form['ticket_type']

        if ticket_type == 'Daily':
            amount = '₹50'
        elif ticket_type == 'Weekly':
            amount = '₹250'
        else:
            amount = '₹800'

        conn = sqlite3.connect('buspass.db')
        cursor = conn.cursor()

        cursor.execute(
            "INSERT INTO passes (name, destination, ticket_type, amount) VALUES (?, ?, ?, ?)",
            (name, destination, ticket_type, amount)
        )

        conn.commit()
        conn.close()

        details = {
            'name': name,
            'destination': destination,
            'ticket_type': ticket_type,
            'amount': amount
        }

    return render_template('index.html', details=details)

if __name__ == '__main__':
    app.run(debug=True)
